export class Foto{
    public id: number;
    public title: string;
    public thumbnailUrl: string;
}